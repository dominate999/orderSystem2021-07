create view `v_orderitem-dishesinfo` as
select `ordersystem`.`orderitem`.`orderitem_id`     AS `orderitem_id`,
       `ordersystem`.`orderitem`.`order_id`         AS `order_id`,
       `ordersystem`.`orderitem`.`dishes_id`        AS `dishes_id`,
       `ordersystem`.`orderitem`.`orderitem_number` AS `orderitem_number`,
       `ordersystem`.`orderitem`.`orderitem_money`  AS `orderitem_money`,
       `ordersystem`.`dishesinfo`.`dishes_name`     AS `dishes_name`,
       `ordersystem`.`dishesinfo`.`dishes_des`      AS `dishes_des`,
       `ordersystem`.`dishesinfo`.`dishes_cate`     AS `dishes_cate`,
       `ordersystem`.`dishesinfo`.`dishes_price`    AS `dishes_price`,
       `ordersystem`.`dishesinfo`.`dishes_photo`    AS `dishes_photo`
from (`ordersystem`.`dishesinfo`
         join `ordersystem`.`orderitem`
              on ((`ordersystem`.`dishesinfo`.`dishes_id` = `ordersystem`.`orderitem`.`dishes_id`)))
order by `ordersystem`.`orderitem`.`orderitem_id`;

-- comment on column `v_orderitem-dishesinfo`.orderitem_id not supported: 单种菜品对应的编号

-- comment on column `v_orderitem-dishesinfo`.order_id not supported: 单种菜品对应的所在订单号

-- comment on column `v_orderitem-dishesinfo`.dishes_id not supported: 单种菜品对应的菜品编号

-- comment on column `v_orderitem-dishesinfo`.orderitem_number not supported: 单种菜品所对应的数量

-- comment on column `v_orderitem-dishesinfo`.orderitem_money not supported: 单种菜品所对应的金额

-- comment on column `v_orderitem-dishesinfo`.dishes_name not supported: 菜品名称

-- comment on column `v_orderitem-dishesinfo`.dishes_des not supported: 菜品描述

-- comment on column `v_orderitem-dishesinfo`.dishes_cate not supported: 菜品类别

-- comment on column `v_orderitem-dishesinfo`.dishes_price not supported: 菜品价格

-- comment on column `v_orderitem-dishesinfo`.dishes_photo not supported: 菜品图片

