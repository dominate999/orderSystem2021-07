create view `v_orderinfo-userinfo` as
select `ordersystem`.`orderinfo`.`order_id`      AS `order_id`,
       `ordersystem`.`orderinfo`.`order_name`    AS `order_name`,
       `ordersystem`.`orderinfo`.`order_time`    AS `order_time`,
       `ordersystem`.`orderinfo`.`order_status`  AS `order_status`,
       `ordersystem`.`orderinfo`.`user_id`       AS `user_id`,
       `ordersystem`.`orderinfo`.`order_number`  AS `order_number`,
       `ordersystem`.`orderinfo`.`order_money`   AS `order_money`,
       `ordersystem`.`userinfo`.`user_name`      AS `user_name`,
       `ordersystem`.`userinfo`.`user_addressed` AS `user_addressed`,
       `ordersystem`.`userinfo`.`user_phone`     AS `user_phone`,
       `ordersystem`.`userinfo`.`user_integral`  AS `user_integral`
from (`ordersystem`.`userinfo`
         join `ordersystem`.`orderinfo` on ((`ordersystem`.`userinfo`.`user_id` = `ordersystem`.`orderinfo`.`user_id`)))
order by `ordersystem`.`orderinfo`.`order_id`;

-- comment on column `v_orderinfo-userinfo`.order_id not supported: 订单编号

-- comment on column `v_orderinfo-userinfo`.order_name not supported: 订单名称

-- comment on column `v_orderinfo-userinfo`.order_time not supported: 订单结算时间

-- comment on column `v_orderinfo-userinfo`.order_status not supported: 状态(未接单，已配送，未配送，已完成）

-- comment on column `v_orderinfo-userinfo`.user_id not supported: 用户编号

-- comment on column `v_orderinfo-userinfo`.order_number not supported: 订单内食物总数量

-- comment on column `v_orderinfo-userinfo`.order_money not supported: 订单总金额

-- comment on column `v_orderinfo-userinfo`.user_name not supported: 用户昵称

-- comment on column `v_orderinfo-userinfo`.user_addressed not supported: 用户地址

-- comment on column `v_orderinfo-userinfo`.user_phone not supported: 电话号码

-- comment on column `v_orderinfo-userinfo`.user_integral not supported: 用户积分

