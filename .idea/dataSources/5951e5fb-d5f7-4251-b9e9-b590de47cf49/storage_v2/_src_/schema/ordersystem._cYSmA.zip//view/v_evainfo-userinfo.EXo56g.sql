create view `v_evainfo-userinfo` as
select `ordersystem`.`evainfo`.`eva_id`          AS `eva_id`,
       `ordersystem`.`evainfo`.`eva_content`     AS `eva_content`,
       `ordersystem`.`evainfo`.`user_id`         AS `user_id`,
       `ordersystem`.`evainfo`.`eva_time`        AS `eva_time`,
       `ordersystem`.`evainfo`.`eva_degree`      AS `eva_degree`,
       `ordersystem`.`userinfo`.`user_account`   AS `user_account`,
       `ordersystem`.`userinfo`.`user_name`      AS `user_name`,
       `ordersystem`.`userinfo`.`user_addressed` AS `user_addressed`,
       `ordersystem`.`userinfo`.`user_phone`     AS `user_phone`,
       `ordersystem`.`userinfo`.`user_photo`     AS `user_photo`
from (`ordersystem`.`evainfo`
         join `ordersystem`.`userinfo` on ((`ordersystem`.`evainfo`.`user_id` = `ordersystem`.`userinfo`.`user_id`)))
order by `ordersystem`.`evainfo`.`eva_id`;

-- comment on column `v_evainfo-userinfo`.eva_id not supported: 评价编号

-- comment on column `v_evainfo-userinfo`.eva_content not supported: 评论内容

-- comment on column `v_evainfo-userinfo`.user_id not supported: 用户编号

-- comment on column `v_evainfo-userinfo`.eva_time not supported: 评价时间

-- comment on column `v_evainfo-userinfo`.eva_degree not supported: 好评度

-- comment on column `v_evainfo-userinfo`.user_account not supported: 用户账号

-- comment on column `v_evainfo-userinfo`.user_name not supported: 用户昵称

-- comment on column `v_evainfo-userinfo`.user_addressed not supported: 用户地址

-- comment on column `v_evainfo-userinfo`.user_phone not supported: 电话号码

-- comment on column `v_evainfo-userinfo`.user_photo not supported: 用户头像

